import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ProductsListComponent } from './products/products-list.component';
import {FormsModule} from '@angular/forms';
import { ConvertToSpacePipe } from './share/convert-to-space.pipe';
import {StarComponent} from './share/star.component';
import {HttpClientModule} from '@angular/common/http';
import { ProductService } from './services/product.service';
import { WelcomeComponent } from './welcome/welcome.component';
import { RouterModule } from '@angular/router';
import { ProductdetailsComponent } from './products/productdetails/productdetails.component';
import { AddProductComponent } from './products/add-product/add-product.component';
import { DeleteProductComponent } from './products/delete-product/delete-product.component';
import { ProductsFormComponent } from './products/products-form/products-form.component';

@NgModule({
  declarations: [
    AppComponent,
    ProductsListComponent,
    ConvertToSpacePipe,
    StarComponent,
    WelcomeComponent,
    ProductdetailsComponent,
    AddProductComponent,
    DeleteProductComponent,
    ProductsFormComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot([
      {path: 'products', component:ProductsListComponent},
      {path: 'welcome', component:WelcomeComponent},
      {path: '', redirectTo:'welcome', pathMatch:'full'},
      {path: 'product/:id', component:ProductdetailsComponent},
      {path: 'addproduct', component:AddProductComponent},
      {path: 'delete/:id', component:DeleteProductComponent},
      {path: 'registerProduct', component:ProductsFormComponent}     
      
    ])
  ],
  providers: [ProductService],
  bootstrap: [AppComponent]
})
export class AppModule { }