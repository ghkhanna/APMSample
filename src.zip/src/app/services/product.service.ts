import { Injectable } from '@angular/core';
import { Product} from '../products/product';
import { HttpClient, HttpErrorResponse, HttpParams} from  '@angular/common/http';
import { Observer, observable, throwError } from 'rxjs';
import {Observable} from 'rxjs';
import { map, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  constructor(private httpClient:HttpClient) { }

  // productSpecificUrl="http://localhost:7543/onlineshop/getProductDetails?productId="

  public getAllProductsDetails():Observable<Product[]>{
    return this.httpClient.get<Product[]>("http://localhost:7543/onlineshop/getAllProductDetails").pipe(catchError(this.handleError));
  }
 
  // public getProductDetails(productId:number):Observable<Product>{
  //   return this.httpClient.get<Product>(this.productSpecificUrl+productId).pipe(catchError(this.handleError));
  // }

  public getProductDetails(productId:number):Observable<Product>{
    let params = new HttpParams();
    params = params.set('productId', productId.toString());
    return this.httpClient.get<Product>("http://localhost:7543/onlineshop/getProductDetails", {params: params}).pipe(catchError(this.handleError));
  }

  public acceptProductDetails(product:Product):void{
    let params = new HttpParams()
    params = params.set('product', product.toString())
    this.httpClient.post<Product>("http://localhost:7543/onlineshop/acceptProductDetails", {params: params})
  }

 public removeProductDetails(productId:number){
  let params = new HttpParams();
  params = params.set('productId', productId.toString());
  return this.httpClient.delete("http://localhost:7543/onlineshop/removeProductDetails", {params: params}).pipe(catchError(this.handleError));
 }

  private handleError(error:any){
    if(error instanceof ErrorEvent){
      console.error('1 An ErrorEvent occured :',error.error.message);
      return throwError(error.error.message);
    }else if(error instanceof HttpErrorResponse){
      console.error(`2 Backend returned code ${error.status}, body was : ${error.message}`);
      return throwError(`Backend returned code ${error.status}, body was : ${error.message}`);
    }
    else if(error instanceof TypeError){
      console.error(`3 Backend returned code ${error.message}, body was : ${error.stack}`);
       return throwError(`Backend returned code ${error.message}, body was : ${error.stack}`);
    }
  }
}