import { Component, OnInit } from '@angular/core';
import {ActivatedRoute,Router} from '@angular/router';
import {Product} from '../product';
import {ProductService} from '../../services/product.service';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit {

  pageTitle: string ='Add Product'
  errorMessage:string
  product: Product
  productId:number
  productName:string
  description:string
  price:number
  starRating:number
  releaseDate:string
  get addProductId() : number{
    return this.productId;
  }

  set addProductId(value:number){
    this.productId = value;
  }

  get addProductName() : string{
    return this.productName;
  }

  set addProductName(value:string){
    this.productName = value;
  }

  get addProductDescription() : string{
    return this.description;
  }

  set addProductDescription(value:string){
    this.description = value;
  }
  get addProductPrice() : number{
    return this.price;
  }

  set addProductPrice(value:number){
    this.price = value;
  }
  get addProductRating() : number{
    return this.starRating;
  }

  set addProductRating(value:number){
    this.starRating = value;
  }
  get addProductReleaseDate() : string{
    return this.releaseDate;
  }

  set addProductReleaseDate(value:string){
    this.releaseDate = value;
  }
  constructor(private productService: ProductService) {
  this.productId
  this.productName
  this.description
  this.price
  this.starRating
  this.releaseDate
  this.product.productId=this.productId
  this.product.productName=this.productName
  this.product.description=this.description
  this.product.price=this.price
  this.product.starRating=this.starRating
  this.product.releaseDate=this.releaseDate
   }

  ngOnInit() {
    this.productService.acceptProductDetails(this.product)
  }

}
