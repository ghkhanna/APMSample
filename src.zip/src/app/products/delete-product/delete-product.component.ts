import { Component, OnInit } from '@angular/core';
import {Product} from '../product';
import {ProductService} from '../../services/product.service';
import {ActivatedRoute,Router} from '@angular/router';


@Component({
  selector: 'app-delete-product',
  templateUrl: './delete-product.component.html',
  styleUrls: ['./delete-product.component.css']
})
export class DeleteProductComponent implements OnInit {
  pageTitle: string ='Delete Product'
  errorMessage:string
  product: Product

  constructor(private route:ActivatedRoute, private router:Router, private productService: ProductService) { }


  ngOnInit() {
    const id = this.route.snapshot.paramMap.get('id');
    const productId = +id;
    this.productService.removeProductDetails(productId).subscribe(
      (productId) => {
        productId=productId
      },
      errorMessage=>{
        this.errorMessage=errorMessage;
      }
    )
  }

  public navigateBack():void{
    this.router.navigate(['/products']);
  }
}