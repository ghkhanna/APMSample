import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-products-form',
  templateUrl: './products-form.component.html',
  styleUrls: ['./products-form.component.css']
})
export class ProductsFormComponent implements OnInit {

  pageTitle:string='Product Registration Form'
  constructor() { }

  ngOnInit() {
  }

}
