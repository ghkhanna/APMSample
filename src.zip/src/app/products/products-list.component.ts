import { Component, OnInit } from '@angular/core';
import { Product } from './product';
import { ProductService } from '../services/product.service';

@Component({
  selector: 'app-products-list',
  templateUrl: './products-list.component.html',
  styleUrls: ['./products-list.component.css']
})
export class ProductsListComponent implements OnInit {

    productListTitle:string='Products List';
    list_Filter:string='';
    error:string;
    productsList: Product[];
    products: Product[];
  


  constructor(private productService:ProductService) {
    this.list_Filter="";
   }

   ngOnInit() {
    this.productService.getAllProductsDetails().subscribe(
      tempProducts=>{
        this.products=tempProducts;
        this.productsList=this.products;
      }
    ,
      error=>{
        this.error=error;
      }
    );
  }

  get listFilter() : string{
    return this.list_Filter;
  }

  set listFilter(value:string){
    this.list_Filter = value;
    this.productsList=this.list_Filter ? this.doProductFiltering(this.list_Filter):this.products;

  }

  doProductFiltering(filterBy:string): Product[]{
    filterBy = filterBy.toLowerCase();
    return this.products.filter(product => product.productName.toLowerCase().indexOf(filterBy)!==-1);
  }

  onRatingClicked(message: string): void{
    this.productListTitle = 'Products List!' +message;
  }

}